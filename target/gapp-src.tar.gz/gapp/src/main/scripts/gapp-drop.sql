drop table additionalinfo cascade;
drop table admin_staff cascade;
drop table applications cascade;
drop table applicationstatus cascade;
drop table degrees cascade;
drop table departments cascade;
drop table programs cascade;
drop table users cascade;
drop table files cascade;


drop sequence hibernate_sequence;