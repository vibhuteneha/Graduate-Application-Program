/*package gapp.model.dao;

import gapp.model.Application;
import gapp.model.Department;
import gapp.model.Program;
import gapp.model.Term;

public interface TermDao {
		
	Term getTerm(String term_name);

	Application getApplication(Integer term_id);
	
	Program getProgram(Integer application_id);
	
	Department getDepartment(Integer program_id);
	
}*/